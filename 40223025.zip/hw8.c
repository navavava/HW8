// نوا جغتایی-40223025
#include <stdio.h>
#include <stdlib.h>
int tts(int mins, int seconds); // converting running time and record into seconds
struct time
{
    int sec;
    int min;
};
struct runner
{
    char firstName[20];
    char lastName[20];
    int ID;
    struct time runningTime;
    struct time *record;
};
int main()
{
    int n, flag, counter;
    printf("how many players are there?\n");
    scanf("%d", &n);
    int arr_i[n], arr_f[n];
    struct runner player[n];
    for (int i = 0; i < n; i++)
    {
        printf("enter the informations of player %d\n", i + 1);
        printf("first name: ");
        scanf("%s", player[i].firstName);
        printf("last name: ");
        scanf("%s", player[i].lastName);
        printf("ID: ");
        scanf("%d", &player[i].ID);
        printf("running time minutes: ");
        scanf("%d", &player[i].runningTime.min);
        printf("running time seconds: ");
        scanf("%d", &player[i].runningTime.sec);
        player[i].record = (struct time *)malloc(8);
        printf("record minutes: ");
        scanf("%d", &player[i].record->min);
        printf("record seconds: ");
        scanf("%d", &player[i].record->sec);
    }
    for (int i = 0; i < n; i++) // creating an array of players
    {
        arr_i[i] = (tts(player[i].runningTime.min, player[i].runningTime.sec));
    }
    for (int i = 0; i < n; i++) // sorting players into a new array based on running time
    {
        counter = 0;
        for (int j = 0; j < n; j++)
        {
            if (arr_i[i] > arr_i[j])
                counter++;
        }
        arr_f[counter] = i;
    }
    printf("%s %s\n", player[arr_f[0]].firstName, player[arr_f[0]].lastName);
    if (tts(player[arr_f[0]].runningTime.min, player[arr_f[0]].runningTime.sec) <
        tts(player[arr_f[0]].record->min, player[arr_f[0]].record->sec))
    {
        printf("the winner has beat her own highscore\n");
        for (int i = 0; i < n; i++) // comparing the winner's running time with overall highscores
        {
            flag = 1;
            if (tts(player[arr_f[0]].runningTime.min, player[arr_f[0]].runningTime.sec) >
                tts(player[i].runningTime.min, player[i].runningTime.sec))
            {
                flag = 0;
            }
        }
        if (flag)
        {
            printf("the winner has beat the overall highscore\n");
        }
    }
    else
    {
        printf("the winner hasn't made a new highscore\n");
    }
    printf("name  last name  running time   id     record\n");
    for (int i = 0; i < n; i++)
    {
        printf("%-6s%-11s%d:%-13d%-10d%d:%d\n", player[arr_f[i]].firstName, player[arr_f[i]].lastName,
               player[arr_f[i]].runningTime.min, player[arr_f[i]].runningTime.sec, player[arr_f[i]].ID,
               player[arr_f[i]].record->min, player[arr_f[i]].record->sec);
    }
    return 0;
}

int tts(int mins, int seconds)
{
    return ((mins * 60) + seconds);
}